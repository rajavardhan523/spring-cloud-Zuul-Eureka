package com.myapplication.eurekaserverzuul;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class EurekaServerZuulApplicationTests {

	@Test
	public void contextLoads() {
	}

}

